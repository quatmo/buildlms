<?php
$configIniPath = '/srv/http/config/config.ini';
$configTxtPath = '/boot/config.txt';
$debugFilePath = '/srv/http/config/debug.txt';

function logToDebugFile($message) {
    global $debugFilePath;
    $log = date('Y-m-d H:i:s') . ': ' . $message . "\n";
    file_put_contents($debugFilePath, $log, FILE_APPEND);
}

$configTxtContent = file_get_contents($configTxtPath);
$configIniContent = file_get_contents($configIniPath);

if (strpos($configTxtContent, 'dtoverlay=disable-bt') !== false) {
    if (strpos($configIniContent, 'dtoverlay=disable-bt') === false) {

        $settingsPos = strpos($configIniContent, '');
        if ($settingsPos !== false) {

            $configIniContent = substr($configIniContent, 0, $settingsPos) .
                "[Settings]\n" .
                "dtoverlay=disable-bt\n" .
                substr($configIniContent, $settingsPos);
            file_put_contents($configIniPath, $configIniContent);
            #logToDebugFile('Added dtoverlay=disable-bt to [Settings] in config.ini.');
        }
    }
} else {
    if (strpos($configIniContent, 'dtoverlay=disable-bt') !== false) {

        $configIniContent = preg_replace('/\[Settings\]\s*dtoverlay=disable-bt/', '', $configIniContent);
        file_put_contents($configIniPath, $configIniContent);
        #logToDebugFile('Removed [Settings] from config.ini.');
    }
}




$updateIniPath = '/srv/http/config/update.ini';
$versionIniPath = '/srv/http/config/version.ini';

$updateIniData = parse_ini_file($updateIniPath);
$versionIniData = parse_ini_file($versionIniPath);

if ($updateIniData === false || $versionIniData === false) {

} else {
    $versionCurrent = isset($versionIniData['number']) ? $versionIniData['number'] : '';
    $versionNew = isset($updateIniData['number']) ? $updateIniData['number'] : '';
    $contentUpdate = isset($updateIniData['text']) ? $updateIniData['text'] : '';

    // if (version_compare($versionNew, $versionCurrent, '>')) {
        // $versionIniData['number'] = $versionNew;
        // $newVersionIniContent = '';
        // foreach ($versionIniData as $key => $value) {
            // $newVersionIniContent .= "$key = \"$value\"\n";
        // }

        // file_put_contents($versionIniPath, $newVersionIniContent);

    // }
}





?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Config for LMSrAudio</title>
   
	<link rel="stylesheet" href="/bub/lib/css/bootstrap.min.css">
    <style>
        body {
            background-color: #1e1e1e;
            color: #ffffff;
        }
        .container {
            background-color: #2e2e2e;
            padding: 20px;
            border-radius: 10px;
            max-width: 600px;
            margin: 0 auto;
            margin-top: 50px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }
        #result {
            margin-top: 20px;
        }
        #resultMessage {
            font-size: 18px;
        }
        .out{
            color: #59c8ff;
            font-weight: 300;
        }

.slider-container {
    display: flex;
    align-items: center;
    width: 300px;
    margin: 0 auto;
}

.slider-container-yt{
    display: flex;
    align-items: center;
    width: 300px;
    margin: 0 auto;
}

.toggle-slider {
    -webkit-appearance: none;
    width: 100%;
    height: 10px;
    border-radius: 5px;
    background: linear-gradient(to right, #00a1ff 0%, #fff 50%, #ffffff 50%, #2196F3 100%);
    outline: none;
    opacity: 0.7;
    -webkit-transition: .2s;
    transition: opacity .2s;
}

.toggle-slider:hover {
    opacity: 1;
}

.toggle-slider::-webkit-slider-thumb {
    -webkit-appearance: none;
    appearance: none;
    width: 44px;
    height: 44px;
    border-radius: 50%;
    background: #007bff;
    cursor: pointer;
    transition: background .3s ease;
    position: relative;
}

.toggle-slider::-moz-range-thumb {
    width: 44px;
    height: 44px;
    border: none;
    border-radius: 50%;
    background: #007bff;
    cursor: pointer;
    transition: background .3s ease;
    position: relative;
}

.toggle-label {
    font-size: 14px;
    color: #fff;
    text-align: center;
    width: 40px;
    margin-top: 10px;
}
.toggle-label-yt {
    font-size: 14px;
    color: #fff;
    text-align: center;
    width: 40px;
    margin-top: 10px;
	margin:20px;
}
.toggle-slider::before {
    content: 'I2S';
    position: absolute;
    top: -30px;
    left: -10px;
    display: block;
    background: #ccc;
    color: #000;
    padding: 5px;
    border-radius: 5px;
    font-size: 12px;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.toggle-slider:hover::before {
    opacity: 1;
}

.toggle-slider::-webkit-slider-thumb::before {
    content: '';
}

.toggle-slider::-moz-range-thumb::before {
    content: '';
}
        .button-container {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
            margin-bottom: 20px; 
        }

        .btn-reboot {
            flex: 1;
            margin: 0 1px;
        }

        .btn-cancel {
            flex: 1;
            margin: 0 1px;
        }
        .dac-i2s {
            margin-top: 20px;
            margin-bottom: 0px; 
        }
		.btn-custom{
			 background: #007bff;
			 color: #fff;
		}
		.btn-custom-cancel{
			 background: #506376;
			 color: #fff;
		}
		.text-container {
			text-align: center;
			margin-top: 10px;
		}

		.gray-hr {
			border-top: 1px solid #6d7278;
		}
    </style>

</head>
<body>

<div class="container mt-5">
    <h3 class="text-center">DAC <span id="dacSettingDisplay" class="out"></span></h3>
    <div class="slider-container">
        <label class="toggle-label">I2S</label>
        <input type="range" min="0" max="1" step="1" class="toggle-slider" id="dacSwitch">
        <label class="toggle-label">USB</label>
    </div>


    <div class="form-group dac-i2s" id="dacI2S" style="display: none;">
        <select id="dacSelect" class="form-control" onchange="handleSelectChange(this)">
            <option value=""></option>
        </select>
    </div>

    
	<div class="button-container " id="buttonContainer" style="display: none;">
			<button type="button" class="btn btn-custom btn-reboot" id="btnReboot" onclick="reboot()">Reboot now</button>
			<button type="button" class="btn btn-custom-cancel btn-cancel" id="btnCancel" onclick="hideButtons()">Reboot later</button>		
	 </div>


	<div id="resulReboot" style="display: none;"></div>
    <form method="post" action="detect_dac.php" onsubmit="handleFormSubmit(event)">
		<div class="form-group">
			<label for="selected_device"></label>
			<div id="usbDacList"></div>
		</div>
		<button type="submit" class="btn btn-custom btn-block">Select</button>
	</form>
</div>

<div class="container mt-5">
    <h3 class="text-center">Server <span id="selectedServer" class="out"></span></h3>
    <div class="slider-container">
        <label class="toggle-label">LMS</label>
        <input type="range" min="0" max="2" step="1" class="toggle-slider" id="slider" value="1">
        <label class="toggle-label">Roon</label>
    </div>

    <div class="form-group" id="roonIpData" style="display: none;">
        <hr class="gray-hr">
        <input id="roonIp" class="form-control"></input>
        <br>
        <div class="button-container">
            <button type="button" class="btn btn-custom btn-reboot" id="applyButton" onclick="applyIP()">Apply</button>
            <button type="button" class="btn btn-custom-cancel btn-cancel" id="cancelButton" onclick="hideButtonsRoon()">Cancel</button>
        </div>
    </div>
	<br>
	<div id="statusMessageLmsIp" class="alert-success alert" style="display: none;">LMS Server configuration for SQ is complete!</div>
	<div id="statusMessageRoonIp" class="alert-success alert" style="display: none;">ROON Server configuration for SQ is complete!</div>
</div>


<div class="container">
    <h3 class="text-center">Squeezelite output to <span id="dacOutputDisplay" class="out"></span></h3>
    <form id="dacForm">
        <div class="form-group">
            <label for="dacSetting"></label>
            <select class="form-control" id="dacSetting" name="dacSetting">
                <option value="default">Default - operates based on rAudio settings</option>
                <option value="eqfa12p">Eqfa12p - operates with 12-band Parametric EQ</option>
                <option value="auto">Auto - Automatically detects DAC hw:#</option>
                <option disabled selected>Select Output:</option>
            </select>
        </div>
        <button type="submit" class="btn btn-custom btn-block">Apply</button>
    </form>

    <div id="result" style="display: none;">
        <hr class="gray-hr">
        <p id="resultMessage"></p>
    </div>
</div>



	
<div class="container">
    <h3 class="text-center">LMSBubV9</h3>
	    <div id="bubV9Result" style="display: none;" class="alert-success alert">
        <p id="bubV9ResultMessage"></p>
		 <hr class="gray-hr">
    </div>
    <form id="bubV9Form">
        <div class="form-group">
            <label for="srvUsername">Username:</label>
            <input type="text" class="form-control" id="srvUsername" name="srvUsername">
        </div>
        <div class="form-group">
            <label for="srvPassword">Password:</label>
            <input type="password" class="form-control" id="srvPassword" name="srvPassword">
        </div>
        <div class="form-group">
            <label for="bubbleServerUrl">Bubble Server URL (http://yourserver:58050)</label>
            <input type="text" class="form-control" id="bubbleServerUrl" name="bubbleServerUrl">
        </div>
        <button type="submit" class="btn btn-custom btn-block">Apply</button>
    </form>
</div>

<div class="container mt-5">
    <h3 class="text-center">LCD</h3>
    <div class="slider-container-yt">
        <label class="toggle-label-yt">Display Youtube</label>
        <input type="range" min="0" max="2" step="1" class="toggle-slider" id="ytSwitch" value="1">
        <label class="toggle-label-yt">Display LMS</label>
    </div>
	<div id="statusMessageYtube" class="alert-success alert" style="display: none;">
		Youtube on LCD has been turned on for the first time.
		<ul>
			<li>Tap the settings icon at the bottom.</li>
			<li>Tap 'Link with TV Code' to display the code.</li>
			<li>Next, in the YouTube app on your phone, select the Cast icon, then 'Link with TV code.'</li>
			<li>Switch the SQ64-rAudio player to off before you play a YouTube video.</li>
			<li>Once completed, you can choose to cast to the TV (Youtube on LCD).</li>			
		
		</ul>
	</div>
	<div id="statusMessageLms" class="alert-success alert" style="display: none;">LMS on LCD has been turned on.</div>

	<hr class="gray-hr">
	<div class="text-container">HDMI CVT <span id="toggle-label-hdmi" class="out"></span></div>
	<div class="slider-container-yt">
	
	<label class="toggle-label-yt">1280 x 720</label>
	<input type="range" min="0" max="2" step="1" class="toggle-slider" id="hdmiDriveSlider" value="1">
	<label class="toggle-label-yt">1920 x 1080</label>

	</div>
	<hr class="gray-hr">
		<div id="statusMessageAdOff" class="alert-success alert" style="display: none;">Your browser is displayed on your screen; you can toggle the Addon on and off to ensure proper Addon functionality.</div>
	<button id="lcdAdButton" onclick="turnOffAd()" class="btn btn-custom btn-block">Browser on LCD</button>
	<hr class="gray-hr">
	<div id="statusMessageTVLCD" class="alert-success alert" style="display: none;">Changing display settings for one of the two HDMI screens. The switch was successful. Rebooting now. Please go back to the Home page and refresh in a minute!</div>
	<button id="tvLcdButton" onclick="turnTVLCD()" class="btn btn-custom btn-block">Switch Screen</button>


	
</div>

<div class="container mt-5">
	<div id="statusMessageLCD" class="alert-success alert" style="display: none;">All cache and cookies in the browser have been cleared.</div>
	<button id="lcdOffButton" onclick="turnOffLCD()" class="btn btn-custom btn-block">Clear browser cache and Turn off screen</button>
	
</div>


<div class="container mt-5">
    <h3 class="text-center">LMS-rAudio <span id="versionCurrent" class="out"><?= $versionCurrent ?></span></h3>
	<div id="statusMessageUpdated" class="alert-success alert" style="display: none;">Updating, the system will automatically reboot once complete. Please refresh after 60 seconds.</div>
    <?php if (version_compare($versionNew, $versionCurrent, '>')) : ?>
        <div id="statusMessageUpdate" class="alert-success alert">
            <span id="versionNew" class="out"><?= $versionNew ?></span>
            <ul>
                <li id="contentUpdate"><?= $contentUpdate ?></li>
            </ul>
            <hr class="gray-hr">
            <button id="onlineUpdate" onclick="updateVersion()" class="btn btn-custom btn-block">Update</button>
        </div>

    <?php endif; ?>
</div>


<script src="/bub/lib/js/jquery-3.2.1.min.js"></script>
<script>

let previousDacValue = '';
let isUserInteracting = false;

function updateDacSwitchPosition() {
    $.ajax({
        url: 'read_config.php',
        method: 'GET',
        dataType: 'text',
        success: function (data) {
            console.log('Received data from PHP:', data);

            const hasDacSetting = /dtoverlay=(?!disable-bt).+/.test(data);

            const dacSwitchElement = document.getElementById('dacSwitch');
            dacSwitchElement.value = hasDacSetting ? '0' : '1';

            handleDacSwitchChange();
        },
        error: function (xhr, status, error) {
            console.error('Error reading config file:', error);
        }
    });
}


function customUpdateDacSetting(selectedDac) {
    if (isUserInteracting) {
        if (selectedDac !== previousDacValue) {
            $.ajax({
                type: 'POST',
                url: 'update_choose_dac.php',
                data: { chooseDac: selectedDac },
                success: function(response) {
                },
                error: function(xhr, status, error) {
                    console.error('Error updating choose Dac:', error);
                }
            });
            previousDacValue = selectedDac;
        }
    }

    $.ajax({
        type: 'GET',
        url: 'detect_dac.php',
        success: function(response) {
            $('#usbDacList').html(response);
        },
        error: function(xhr, status, error) {
            console.error('Error updating USB DAC list:', error);
        }
    });
}


function handleDacSwitchChange() {
    const dacSwitch = document.getElementById('dacSwitch');
    const selectedDac = dacSwitch.value === '1' ? 'USB' : 'I2S';
    document.getElementById('dacSettingDisplay').innerText = selectedDac;
    customUpdateDacSetting(selectedDac);

    if (selectedDac === 'I2S') {
        showDacI2S();
    } else {

        hideDacI2S();
    }
}


document.getElementById('dacSwitch').addEventListener('input', function() {
    isUserInteracting = true;
    handleDacSwitchChange();
});

document.getElementById('dacSwitch').addEventListener('mouseup', function() {
    isUserInteracting = false;
});

updateDacSwitchPosition();

function readDacSetting() {
    $.ajax({
        url: 'read_dac_setting.php',
        method: 'GET',
        dataType: 'text',
        success: function (data) {
            $('#dacOutputDisplay').text(data);
        },
        error: function (xhr, status, error) {
            console.error('Error reading DAC setting:', error);
        }
    });
}

readDacSetting();

function runScript() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState == XMLHttpRequest.DONE) {
            if (xhr.status == 200) {

            } else {

            }
        }
    };
    xhr.open("GET", "run_eq_script.php", true);
    xhr.send();
}

document.getElementById('dacForm').addEventListener('submit', function(event) {
	event.preventDefault();

	const selectedSetting = document.getElementById('dacSetting').value;

	let command;
	if (selectedSetting === 'default') {
		command = 'Replaced successfully! The output: -o default.';
	} else if (selectedSetting === 'eqfa12p') {
		command = 'Replaced successfully! The output: -o eqfa12p.';
	} else if (selectedSetting === 'auto') {
		command = 'Replaced successfully! The output: -o hw:$card.';
	}

  document.getElementById('result').innerHTML = `<div class="alert alert-success">${command}</div>`;
    });
	
	   $(document).ready(function() {
        $('#dacForm').submit(function(e) {
            e.preventDefault();

            var formData = $(this).serialize();

            $.ajax({
                type: 'POST',
                url: 'update_dac_setting.php',
                data: formData,
                success: function(response) {
                    runScript()
                    $('#result').show();
                    $('#resultMessage').text(response);
                }
            });
        });
    });

    $(document).ready(function() {
        $('#bubV9Form').submit(function(e) {
            e.preventDefault();

            var formData = $(this).serialize();

            $.ajax({
                type: 'POST',
                url: 'update_bubv9_config.php',
                data: formData,
                success: function(response) {
                    // Display the result for BubV9
                    $('#bubV9Result').show();
                    $('#bubV9ResultMessage').text(response);
                }
            });
        });
    });
	
    function updateUsbDacList() {
    $.ajax({
        url: 'detect_dac.php',
        method: 'GET',
        dataType: 'text',
        success: function(data) {
            $('#usbDacList').html(data);
            // Console log DAC
            // console.log('Detected DACs:', data);
        },
        error: function(xhr, status, error) {
            console.error('Error detecting DAC:', error);
        }
    });
}

function updateButtonStates() {
    const selectedDac = document.getElementById('dacSwitch').value;
    const buttonContainer = document.getElementById('buttonContainer');

    if (selectedDac === '0' || selectedDac === '1') {
        buttonContainer.style.display = 'flex';
        
    } else {
        buttonContainer.style.display = 'none';
       
    }
}

document.getElementById('dacSwitch').addEventListener('input', function() {
    isUserInteracting = true;
    updateUsbDacList();
    handleDacSwitchChange();
    updateButtonStates();
});


document.getElementById('btnReboot').addEventListener('click', function() {
    document.getElementById('btnReboot').innerText = 'Rebooting...';

    var resulRebootElement = document.getElementById('resulReboot');
    if (resulRebootElement) {
        resulRebootElement.innerHTML = '<p class="alert alert-success" >Rebooting... Please return to the Home page and refresh after 1 minute and 30 seconds!</p>';
        resulRebootElement.style.display = 'block';
    }

    reboot();
});


function reboot() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState == XMLHttpRequest.DONE) {
            if (xhr.status == 200) {
                // Handle a successful reboot if needed
            } else {
                // Handle an error during reboot if needed
            }
        }
    };
    xhr.open("GET", "run_script_reboot.php", true);
    xhr.send();
}


function hideButtons() {
    const buttonContainer = document.getElementById('buttonContainer');
    buttonContainer.style.display = 'none';
}


function updateDacSelectOptions() {
    var dacSelect = document.getElementById("dacSelect");
    if (dacSelect) {

        dacSelect.innerHTML = "";


        var defaultOption = document.createElement("option");
        defaultOption.value = "";
        defaultOption.text = "I2S driver:";
        defaultOption.disabled = true;
        defaultOption.selected = true;
        dacSelect.appendChild(defaultOption);


        var xhr = new XMLHttpRequest();
        xhr.open("GET", "read_i2s.php", true);
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                var data = JSON.parse(xhr.responseText);


                for (var name in data) {
                    var option = document.createElement("option");
                    option.value = data[name];
                    option.text = name;
                    dacSelect.appendChild(option);
                }
            }
        };
        xhr.send();
    } else {
        console.error("Not dacSelect.");
    }
}


function handleSelectChange(selectElement) {
    var selectedDacI2S = selectElement.value;
    if (selectedDacI2S) {

        console.log("DAC I2S: " + selectedDacI2S);
		buttonContainer.style.display = 'flex';

        updateConfig(selectedDacI2S);

        updateChooseDac('I2S');
    }
}

function updateChooseDac(selectedDac) {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "update_choose_dac.php", true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    
    xhr.onload = function() {
        if (xhr.status === 200) {

            console.log(xhr.responseText);
        } else {

            console.error('Request failed with status:', xhr.status);
        }
    };
    
    xhr.onerror = function() {

        console.error('Network error occurred');
    };
    
    xhr.send("chooseDac=" + selectedDac);
}


function updateConfig(selectedDacI2S) {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "update_i2s.php", true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            console.log(xhr.responseText); 
        }
    };
    xhr.send("selectedDacI2S=" + selectedDacI2S);
}

document.addEventListener("DOMContentLoaded", function () {
    updateDacSelectOptions();
});

function showDacI2S() {
    var dacI2S = document.getElementById("dacI2S");
    if (dacI2S) {
        dacI2S.style.display = "block";
    }
}

function hideDacI2S() {
    var dacI2S = document.getElementById("dacI2S");
    if (dacI2S) {
        dacI2S.style.display = "none";
    }
}

const ytSwitch = document.getElementById("ytSwitch");

ytSwitch.addEventListener("change", function() {
    const value = ytSwitch.value;
    update_lcd(value);
});

function update_lcd(value) {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                console.log('OK: ' + xhr.responseText);
				if (value === '0') {
                    displayMessageYtube();
                } else if (value === '2') {
                    displayMessageLMS();
                } else {
                   
                }
  
            } else {
                console.error('Error: ' + xhr.status);
              
            }
        }
    };
    xhr.open("POST", "update_lcd.php", true);
    xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhr.send(JSON.stringify({ value: value }));
}


document.getElementById("slider").addEventListener("input", function() {
    let sliderValue = this.value;

    console.log("Slider value changed to: " + sliderValue);

    if (sliderValue == 0) {
        console.log("Switched to LMS");
        changeStatus();
		handleIp();
		displayMessageLmsIp();
    } else {
        console.log("Switched to Roon");
        document.getElementById("roonIpData").style.display = "block";
        loadRoonIP();
		
    }
});



function changeStatus() {
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            console.log("Status updated for Local IP (LMS).");
        }
    };
    xhttp.open("POST", "update_local_ip.php", true);
    xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhttp.send();
}




function loadRoonIP() {
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let roonIP = this.responseText;
            document.getElementById("roonIp").value = roonIP;
            console.log("Roon IP loaded: " + roonIP);
        }
    };
    xhttp.open("GET", "get_roon_ip.php", true);
    xhttp.send();
}


function applyIP() {
    let newRoonIP = document.getElementById("roonIp").value;
    let sliderValue = document.getElementById("slider").value;

    console.log("New Roon IP applied: " + newRoonIP);

    let data = {
        roonIP: newRoonIP,
        sliderValue: sliderValue
    };


    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            console.log("IP configuration updated on the server.");
           
        }
    };
    xhttp.open("POST", "update_ip.php", true);
    xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhttp.send(JSON.stringify(data));
	handleIp();
	displayMessageRoonIp();
	

}


function hideButtonsRoon() {
    roonIpData.style.display = 'none';
    console.log('Hiding Roon IP input form');
}

function displayMessageYtube() {
    document.getElementById('statusMessageYtube').style.display = 'block';

}

function displayMessageLMS() {
    document.getElementById('statusMessageLms').style.display = 'block';

}

function displayMessageLCDOff() {
    document.getElementById('statusMessageLCD').style.display = 'block';
	document.getElementById('lcdOffButton').innerText = 'The screen has been turned off!';

}

function displayMessageLmsIp() {
    document.getElementById('statusMessageLmsIp').style.display = 'block';

}

function displayMessageRoonIp() {
    document.getElementById('statusMessageRoonIp').style.display = 'block';

}

function displayMessageTVLCD() {
    document.getElementById('statusMessageTVLCD').style.display = 'block';
	document.getElementById('tvLcdButton').innerText = 'Rebooting...';
}


function displayMessageAdOff() {
    document.getElementById('statusMessageAdOff').style.display = 'block';
	document.getElementById('lcdAdButton').innerText = 'Successful Browser Display on LCD!';
}

function displayMessageUpdated() {
    document.getElementById('statusMessageUpdated').style.display = 'block';
	document.getElementById('onlineUpdate').innerText = 'Rebooting...';
}


function handleIp() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState == XMLHttpRequest.DONE) {
            if (xhr.status == 200) {
                // Handle a successful reboot if needed
            } else {
                // Handle an error during reboot if needed
            }
        }
    };
    xhr.open("GET", "handle_ip.php", true);
    xhr.send();
}


function updateVersion() {
    var xhr = new XMLHttpRequest();
	displayMessageUpdated();
    xhr.onreadystatechange = function() {
        if (xhr.readyState == XMLHttpRequest.DONE) {
            if (xhr.status == 200) {
                // Handle a successful Update if needed
				// location.reload();
            } else {
                // Handle an error during Update if needed
            }
        }
    };
    xhr.open("GET", "run_script_update.php", true);
    xhr.send();
}

function turnTVLCD() {
    var xhr = new XMLHttpRequest();
	displayMessageTVLCD();
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                console.log('LCD off');

            } else {
                console.error('Error: ' + xhr.status);
            }
        }
    };
    xhr.open("POST", "run_script_swlcd.php", true);
    xhr.send();
}

function turnOffLCD() {
    var xhr = new XMLHttpRequest();
	displayMessageLCDOff();
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                console.log('LCD off');

            } else {
                console.error('Error: ' + xhr.status);
            }
        }
    };
    xhr.open("POST", "turn_off_lcd.php", true);
    xhr.send();
}

function turnOffAd() {
    var xhr = new XMLHttpRequest();
	displayMessageAdOff();
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                console.log('AD off');

            } else {
                console.error('Error: ' + xhr.status);
            }
        }
    };
    xhr.open("POST", "turn_off_ad.php", true);
    xhr.send();
}

const hdmiDriveSlider = document.getElementById("hdmiDriveSlider");

hdmiDriveSlider.addEventListener("input", function () {
    updateLabel();
});

hdmiDriveSlider.addEventListener("change", function () {
    let value = hdmiDriveSlider.value;
    value = value === '0' ? 'one' : 'two';

    updateHdmiDrive(value);
});

function updateLabel() {
    const label = document.querySelector('#toggle-label-hdmi');
    label.innerText = hdmiDriveSlider.value === '0' ? '1280 x 720' : '1920 x 1080';
}

function updateHdmiDrive(value) {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                console.log('Response: ' + xhr.responseText);
            } else {
                console.error('Error: ' + xhr.status);
            }
        }
    };
    xhr.open("POST", "update_hdmi_drive.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.send("hdmiValue=" + encodeURIComponent(value));
}




</script>	
		
</body>
</html>
