<?php
$commandre = "/usr/bin/sudo /srv/http/config/unit/startLCD.sh";
$outputre = shell_exec($commandre);

if ($outputre === null) {
    http_response_code(500);
    echo "Cannot reboot";
} else {
    http_response_code(200);
    echo "Reboot now";

}

?>

