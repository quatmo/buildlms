#!/bin/bash

/usr/bin/sudo systemctl stop localbrowser.service


if [ ! -f "/srv/http/config/lms" ]; then
/usr/bin/sudo touch /srv/http/config/lms

/usr/bin/sudo find /root/.mozilla/firefox -maxdepth 1 -type d -name '*.default-release' -exec rm -rf {} \;
/usr/bin/sudo find /root/.mozilla/firefox -maxdepth 1 -type d -name '*.default' -exec rm -rf {} \;
/usr/bin/sudo rm /root/.mozilla/firefox/*
/usr/bin/sudo rm -rf /root/.cache/mozilla/firefox/*
sleep 1
fi



if [ -f "/srv/http/config/lmson" ]; then
    rm "/srv/http/config/lmson"
fi

if [ ! -f "/srv/http/config/yton" ]; then
    touch "/srv/http/config/yton"
fi

tar -xzvf /srv/http/config/unit/ytube.tar.gz --overwrite -C /
sleep 0.5
/usr/bin/sudo /usr/bin/systemctl daemon-reload
/usr/bin/sudo /usr/bin/systemctl restart localbrowser.service
/usr/bin/sudo /usr/bin/systemctl enable localbrowser.service
/usr/bin/sudo /usr/bin/systemctl stop localbrowser.service
sleep 2
/usr/bin/sudo tar -xzvf /srv/http/config/unit/exten.tgz --overwrite -C /root/.mozilla/firefox/*.default-release

sleep 1

/usr/bin/sudo chown -Rv http:http /root/.mozilla/firefox/*.default-release
sleep 1

/usr/bin/sudo chown -Rv http:http /root/.mozilla/firefox/*/extensions.json

extension_id1="{0d7cafdd-501c-49ca-8ebb-e3341caaa55e}"

/usr/bin/sudo jq --arg id "$extension_id1" '.addons |= map(if .id == $id then . + { "userDisabled": false, "active": true } else . end)' /root/.mozilla/firefox/*.default-release/extensions.json > /root/.mozilla/firefox/extensions_temp1a.json && /usr/bin/sudo mv /root/.mozilla/firefox/extensions_temp1a.json /root/.mozilla/firefox/*.default-release/

extension_id2="{d2bcedce-889b-4d53-8ce9-493d8f78612a}"

/usr/bin/sudo jq --arg id "$extension_id2" '.addons |= map(if .id == $id then . + { "userDisabled": false, "active": true } else . end)' /root/.mozilla/firefox/*.default-release/extensions.json > /root/.mozilla/firefox/extensions_temp2a.json && /usr/bin/sudo mv /root/.mozilla/firefox/extensions_temp2a.json /root/.mozilla/firefox/*.default-release/

extension_id3="{87ce8680-7931-493f-9125-19c2c7ca092a}"

/usr/bin/sudo jq --arg id "$extension_id3" '.addons |= map(if .id == $id then . + { "userDisabled": false, "active": true } else . end)' /root/.mozilla/firefox/*.default-release/extensions.json > /root/.mozilla/firefox/extensions_temp3a.json && /usr/bin/sudo mv /root/.mozilla/firefox/extensions_temp3a.json /root/.mozilla/firefox/*.default-release/


extension_id4="{9bf64506-bcb0-4e36-b63d-5e45ad974e02}"

/usr/bin/sudo jq --arg id "$extension_id4" '.addons |= map(if .id == $id then . + { "userDisabled": false, "active": true } else . end)' /root/.mozilla/firefox/*.default-release/extensions.json > /root/.mozilla/firefox/extensions_temp4.json && /usr/bin/sudo mv /root/.mozilla/firefox/extensions_temp4.json /root/.mozilla/firefox/*.default-release/

#find /root/.mozilla/firefox/*.default-release -name prefs.js -exec sed -i 's/user_pref("media.autoplay.default",.*/user_pref("media.autoplay.default", 0);/' {} +
/usr/bin/sudo sed -i '/user_pref("media.autoplay.default",/d' /root/.mozilla/firefox/*.default-release/prefs.js
/usr/bin/sudo sed -i '/user_pref("media.autoplay.default",/d' /root/.mozilla/firefox/*.default-release/user.js

echo 'user_pref("media.autoplay.default", 0);' | /usr/bin/sudo tee -a /root/.mozilla/firefox/*.default-release/prefs.js
echo 'user_pref("media.autoplay.default", 0);' | /usr/bin/sudo tee -a /root/.mozilla/firefox/*.default-release/user.js



/usr/bin/sudo /usr/bin/systemctl daemon-reload
/usr/bin/sudo /usr/bin/systemctl restart localbrowser.service


