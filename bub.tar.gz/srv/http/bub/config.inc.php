<?php

$_CONFIG['srv_username'] = "admin";
$_CONFIG['srv_password'] = "admin";
$_CONFIG['bubbleServerUrl'] = 'http://harmona.dyndns-ip.com:58050';
?>