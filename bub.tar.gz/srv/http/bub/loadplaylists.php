<?php
function playLMSPlaylist($playerId, $playlistName) {
    $lmsAddress = 'http://127.0.0.1:9000';

    $url = "{$lmsAddress}/status.html?p0=playlist&p1=play&p2={$playlistName}&player={$playerId}";

    $response = file_get_contents($url);

    if ($response !== false) {
        echo "Playlist {$playlistName} is now playing on player with ID: {$playerId}.";
    } else {
        $errorMessage = "Error playing playlist {$playlistName} on player with ID: {$playerId}.";

        $logFile = '/srv/http/bub/logfile.log';
        file_put_contents($logFile, $errorMessage . PHP_EOL, FILE_APPEND);
        echo $errorMessage;
    }
}

$playerId = '00:00:00:00:00:00';
$playlistName = '/srv/http/bub/nas.m3u';

playLMSPlaylist($playerId, $playlistName);
?>
