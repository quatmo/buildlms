
<?php
function savePlaylist($playlistData) {
    $filePath = '/srv/http/bub/nas.m3u';

    file_put_contents($filePath, "");

    file_put_contents($filePath, $playlistData, FILE_APPEND);

    echo "Playlist saved successfully.";
}

if (isset($_POST['playlistData'])) {
    $playlistData = $_POST['playlistData'];
    savePlaylist($playlistData);
} else {
    echo "No playlist data received.";
}
?>
