
config = {
	defaultBitrate: 0,
	seekableTracksEnabled: false,
	debugMsgs: false
}
