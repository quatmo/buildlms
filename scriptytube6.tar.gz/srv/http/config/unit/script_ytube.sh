#!/bin/bash

/usr/bin/sudo systemctl stop localbrowser.service


if [ ! -f "/srv/http/config/lms" ]; then
/usr/bin/sudo touch /srv/http/config/lms

/usr/bin/sudo find /root/.mozilla/firefox -maxdepth 1 -type d -name '*.default-release' -exec rm -rf {} \;
/usr/bin/sudo find /root/.mozilla/firefox -maxdepth 1 -type d -name '*.default' -exec rm -rf {} \;
/usr/bin/sudo rm /root/.mozilla/firefox/*
/usr/bin/sudo rm -rf /root/.cache/mozilla/firefox/*
sleep 1
fi



if [ -f "/srv/http/config/lmson" ]; then
    rm "/srv/http/config/lmson"
fi

if [ ! -f "/srv/http/config/yton" ]; then
    touch "/srv/http/config/yton"
fi

tar -xzvf /srv/http/config/unit/ytube.tar.gz --overwrite -C /
sleep 0.5
/usr/bin/sudo /usr/bin/systemctl daemon-reload
/usr/bin/sudo /usr/bin/systemctl restart localbrowser.service
/usr/bin/sudo /usr/bin/systemctl enable localbrowser.service
/usr/bin/sudo /usr/bin/systemctl stop localbrowser.service
/usr/bin/sudo rm -f /root/.mozilla/firefox/*.default-release/extensions_temp1a.json
/usr/bin/sudo rm -f /root/.mozilla/firefox/*.default-release/extensions_temp2a.json
/usr/bin/sudo rm -f /root/.mozilla/firefox/*.default-release/extensions_temp3a.json
/usr/bin/sudo rm -f /root/.mozilla/firefox/*.default-release/extensions_temp4a.json
sleep 2
/usr/bin/sudo tar -xzvf /srv/http/config/unit/exten.tgz --overwrite -C /root/.mozilla/firefox/*.default-release

sleep 1

/usr/bin/sudo chown -Rv http:http /root/.mozilla/firefox/*.default-release
sleep 1

/usr/bin/sudo chown -Rv http:http /root/.mozilla/firefox/*/extensions.json

extension_id1="{ce4dfac1-71bc-497b-bcfa-ddce596f785a}"

/usr/bin/sudo jq --arg id "$extension_id1" '.addons |= map(if .id == $id then . + { "userDisabled": false, "active": true } else . end)' /root/.mozilla/firefox/*.default-release/extensions.json > /root/.mozilla/firefox/extensions_temp1a.json && /usr/bin/sudo mv /root/.mozilla/firefox/extensions_temp1a.json /root/.mozilla/firefox/*.default-release/

extension_id2="{1395f22c-2e1f-43c1-98b4-9b8393bcbf79}"

/usr/bin/sudo jq --arg id "$extension_id2" '.addons |= map(if .id == $id then . + { "userDisabled": false, "active": true } else . end)' /root/.mozilla/firefox/*.default-release/extensions.json > /root/.mozilla/firefox/extensions_temp2a.json && /usr/bin/sudo mv /root/.mozilla/firefox/extensions_temp2a.json /root/.mozilla/firefox/*.default-release/

extension_id3="{75039a18-dde5-4aac-a604-3977f48aca4c}"

/usr/bin/sudo jq --arg id "$extension_id3" '.addons |= map(if .id == $id then . + { "userDisabled": false, "active": true } else . end)' /root/.mozilla/firefox/*.default-release/extensions.json > /root/.mozilla/firefox/extensions_temp3a.json && /usr/bin/sudo mv /root/.mozilla/firefox/extensions_temp3a.json /root/.mozilla/firefox/*.default-release/


extension_id4="{b12cdc65-8b44-4fbd-9001-bfa4701ca1a8}"

/usr/bin/sudo jq --arg id "$extension_id4" '.addons |= map(if .id == $id then . + { "userDisabled": false, "active": true } else . end)' /root/.mozilla/firefox/*.default-release/extensions.json > /root/.mozilla/firefox/extensions_temp4.json && /usr/bin/sudo mv /root/.mozilla/firefox/extensions_temp4.json /root/.mozilla/firefox/*.default-release/

#find /root/.mozilla/firefox/*.default-release -name prefs.js -exec sed -i 's/user_pref("media.autoplay.default",.*/user_pref("media.autoplay.default", 0);/' {} +
/usr/bin/sudo sed -i '/user_pref("media.autoplay.default",/d' /root/.mozilla/firefox/*.default-release/prefs.js
/usr/bin/sudo sed -i '/user_pref("media.autoplay.default",/d' /root/.mozilla/firefox/*.default-release/user.js

echo 'user_pref("media.autoplay.default", 0);' | /usr/bin/sudo tee -a /root/.mozilla/firefox/*.default-release/prefs.js
echo 'user_pref("media.autoplay.default", 0);' | /usr/bin/sudo tee -a /root/.mozilla/firefox/*.default-release/user.js



/usr/bin/sudo /usr/bin/systemctl daemon-reload
/usr/bin/sudo /usr/bin/systemctl restart localbrowser.service


