<?php

$configFilePath = '/srv/http/config/config.txt';


$configIniPath = '/srv/http/config/config.ini';


$selectedDacI2S = trim($_POST['selectedDacI2S']);


$logMessage = date('Y-m-d H:i:s') . ': Selected DAC: ' . $selectedDacI2S . PHP_EOL;


$configFile = file_get_contents($configFilePath);


$lines = explode("\n", $configFile);


$newLines = [];

foreach ($lines as $line) {

    if (strpos($line, "dtoverlay=") !== false) {

        $newLines[] = "dtoverlay=$selectedDacI2S";
    } else {

        $newLines[] = $line;
    }
}


$configFile = implode("\n", $newLines);
file_put_contents($configFilePath, $configFile);


$configIniContent = parse_ini_file($configIniPath, true);


$configIniContent['DAC']['dtoverlay'] = $selectedDacI2S;


$configIniData = '';
foreach ($configIniContent as $section => $values) {
    $configIniData .= "[$section]\n";
    foreach ($values as $key => $value) {
        if ($key === 'dtoverlay') {
            $configIniData .= "$key=$value\n";
        } else {
            $configIniData .= "$key = $value\n";
        }
    }
}

file_put_contents($configIniPath, $configIniData);

		
$logMessage .= 'OK!';

echo $logMessage;
?>
