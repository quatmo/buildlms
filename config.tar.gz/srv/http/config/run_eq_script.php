<?php
$command = "/srv/http/config/unit/startsq.sh";
$output = shell_exec($command);

if ($output === null) {
    http_response_code(500);
    echo "Cannot";
} else {
    http_response_code(200);
    echo "Config /etc/alsa/conf.d/eqfa12p.conf";
}
?>
