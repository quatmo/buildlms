<?php
$file_path = '/opt/sq/sq.sh';

// Check if the file exists and is readable
if (file_exists($file_path) && is_readable($file_path)) {
    // Read the content of the file
    $file_content = file_get_contents($file_path);

    // Use regular expressions to extract the value after "-o"
     $pattern = '/\/opt\/sq\/squeezelite[^ ]*\s+-o\s+([^\s]+)/';

    preg_match($pattern, $file_content, $matches);

    // Check if a match was found
    if (isset($matches[1])) {
        // Extracted value after "-o"
        $dac_setting = trim($matches[1]);

        // Output the DAC setting value
        echo $dac_setting;
    } else {
        echo 'DAC setting not found in the file.';
    }
} else {
    echo 'Unable to read the file.';
}
?>
