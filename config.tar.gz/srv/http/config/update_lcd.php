<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"));
    $value = $data->value;
    
    // Set the shell script file based on the value
    if ($value === '0') {
        $command1 = "/usr/bin/sudo /srv/http/config/unit/script_ytube.sh";
        shell_exec($command1);
    } elseif ($value === '2') {
        $command2 = "/usr/bin/sudo /srv/http/config/unit/script_lms.sh";
        shell_exec($command2);
    }

    // Gửi phản hồi nếu cần
    echo "Giá trị $value đã được xử lý thành công.";
} else {
    // Yêu cầu không sử dụng phương thức POST
    echo "Lỗi: Yêu cầu không sử dụng phương thức POST.";
}
?>
