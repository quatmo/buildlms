<?php
$configFilePath = '/boot/config.txt';

$configContent = file_get_contents($configFilePath);

#$logFilePath = __DIR__ . '/log.txt';

#file_put_contents($logFilePath, $configContent);

echo $configContent;
?>
