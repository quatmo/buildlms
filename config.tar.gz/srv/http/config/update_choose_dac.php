<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["chooseDac"])) {
    $selectedDacSetting = $_POST["chooseDac"];

    if ($selectedDacSetting === "I2S") {
        $command = "/usr/bin/sudo /srv/http/config/unit/update_dtoverlay.sh I2S";
        $output = exec($command);
    } elseif ($selectedDacSetting === "USB") {
        $command = "/usr/bin/sudo /srv/http/config/unit/update_dtoverlay.sh USB";
        $output = exec($command);
    } else {
        echo 'Invalid DAC setting.';
    }
} else {
    echo 'Invalid request.';
}
?>
