<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $srvUsername = $_POST['srvUsername'];
    $srvPassword = $_POST['srvPassword'];
    $bubbleServerUrl = $_POST['bubbleServerUrl'];

    // Validate the input if needed

    // Update the config file content
    $configFilePath = '/srv/http/bub/config.inc.php';
    $configContent = "<?php\n\n";
    $configContent .= "\$_CONFIG['srv_username'] = \"$srvUsername\";\n";
    $configContent .= "\$_CONFIG['srv_password'] = \"$srvPassword\";\n";
    $configContent .= "\$_CONFIG['bubbleServerUrl'] = '$bubbleServerUrl';\n";
    $configContent .= "?>";

    file_put_contents($configFilePath, $configContent);

    // Provide a success message or any relevant response
    echo 'Config updated successfully.';
} else {
    echo 'Invalid request method.';
}
?>
