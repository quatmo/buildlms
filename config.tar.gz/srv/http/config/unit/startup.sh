#!/bin/bash

chown http:http /etc/alsa/conf.d/eqfa12p.conf
chown http:http /srv/http/data/mpdconf/eq12.conf

lan_ip=$(ip -4 addr show dev end0 | grep -oP '(?<=inet\s)\d+(\.\d+){3}')
echo $lan_ip

if [ -z "$lan_ip" ]; then
    wifi_ip=$(ip -4 addr show dev wlan0 | grep -oP '(?<=inet\s)\d+(\.\d+){3}')
    if [ -z "$wifi_ip" ]; then
        WEB="raudio"
    else
        WEB=$wifi_ip
    fi
else
    WEB=$lan_ip
fi

TMPFILE=/srv/http/config/unit/actions.txt
FILE=/opt/logitechmediaserver-git/prefs/material-skin/actions.json

if [ ! -f "$FILE" ]; then
	mkdir -p /opt/logitechmediaserver-git/prefs/material-skin
	
    cp -f "/srv/http/config/unit/material-skin/actions.json" "/opt/logitechmediaserver-git/prefs/material-skin/"
    echo "Đã sao chép."
else
    echo "đã tồn tại."
fi



cat << _EOF_ > $TMPFILE
{
  "system":[
	{
      "title":"LMSBubv9 Server",
	  "iframe":"http://$WEB/bub",
      "icon":""
    },
	{
      "title":"Parametric EQfa12",
	  "iframe":"http://$WEB/eqfa12",
      "icon":""
    },
	{
      "title":"Configuration",
	  "iframe":"http://$WEB/config",
      "icon":""
    },
	{
      "title":"Scan Library",
	  "iframe":"http://$WEB:9000/Default/settings/index.html",
      "icon":""
    },
	{
      "title":"rAudio",
	  "iframe":"http://$WEB/web.php",
      "icon":""
    },
	{
      "title":"Reboot",
      "command":"/srv/http/config/unit/reboot.sh",
	  "prompt":"Reboot now?"
    },
	{
      "title":"Shutdown",
      "command":"/srv/http/config/unit/shutdown.sh",
	  "prompt":"Shutdown now?"
    }
	]
}
_EOF_

sed 's/bus./bus.$emit/g' $TMPFILE > $FILE

source_index="/srv/http/config/unit/index.html"
destination_index="/srv/http/"

if [ ! -f "$destination_index" ]; then
    cp -f "$source_index" "$destination_index"
	chown http:http /srv/http/index.html
    echo "Sao chép"
else
    echo "đã tồn tại."
fi


if [ -e "/srv/http/index.php" ]; then
  cp -f /srv/http/index.php /srv/http/web.php
  rm /srv/http/index.php
fi

chown logitechms:logitechms /opt/logitechmediaserver-git/prefs/material-skin/actions.json

chown http:http /etc/asound.conf
chown http:http /srv/http/web.php

grep -q "dtparam=audio=off" /boot/config.txt
if [ $? -eq 0 ]; then
echo "onboard off"
else
echo "dtparam=audio=off" | sudo tee -a /boot/config.txt
echo "onboard to off"
fi

file_to_edit="/srv/http/bash/power.sh"
search_string="mpc -q stop"
replace_string="/usr/bin/sudo /usr/bin/systemctl stop logitechmediaserver-git.service"

if [ -e "$file_to_edit" ]; then
  if grep -q "$search_string" "$file_to_edit"; then
    sed -i "s#$search_string#$replace_string#g" "$file_to_edit"
    echo "Replacement completed in $file_to_edit."
  else
    echo "No match found for '$search_string' in $file_to_edit. Skipping replacement."
  fi
else
  echo "File $file_to_edit does not exist. Skipping."
fi

file_to_edit="/srv/http/bash/power.sh"
search_string="mpc -q stop"
replace_string="/usr/bin/sudo /usr/bin/systemctl stop logitechmediaserver-git.service"

if [ -e "$file_to_edit" ]; then
  if grep -q "$search_string" "$file_to_edit"; then
    sed -i "s#$search_string#$replace_string#g" "$file_to_edit"
    echo "Replacement completed in $file_to_edit."
  else
    echo "No match found for '$search_string' in $file_to_edit. Skipping replacement."
  fi
else
  echo "File $file_to_edit does not exist. Skipping."
fi


playlist_folder="/mnt/PLAYLIST"
playlist_shortcut="/PLAYLIST"

if [ ! -d "$playlist_folder" ]; then
    mkdir -p "$playlist_folder"
	chown logitechms:logitechms /mnt/PLAYLIST
    echo "Đã tạo thư mục"
else
    echo "đã tồn tại."
fi

if [ ! -e "$playlist_shortcut" ]; then
    ln -s "$playlist_folder" "$playlist_shortcut"
    echo "Đã tạo link"
else
    echo " đã tồn tại."
fi

nas_folder="/mnt/MPD/NAS"
nas_shortcut="/NAS"

if [ ! -e "$nas_shortcut" ]; then
    ln -s "$nas_folder" "$nas_shortcut"
    echo "Đã tạo link"
else
    echo " đã tồn tại."
fi


usb_folder="/mnt/MPD/USB"
usb_shortcut="/USB"

if [ ! -e "$usb_shortcut" ]; then
    ln -s "$usb_folder" "$usb_shortcut"
    echo "Đã tạo link"
else
    echo " đã tồn tại."
fi

sd_folder="/mnt/MPD/SD"
sd_shortcut="/SDCARD"

if [ ! -e "$sd_shortcut" ]; then
    ln -s "$sd_folder" "$sd_shortcut"
    echo "Đã tạo link"
else
    echo " đã tồn tại."
fi



