#!/bin/bash
/usr/bin/sudo /usr/bin/systemctl stop sq.service
#/usr/bin/sudo /usr/bin/systemctl stop logitechmediaserver-git.service
#/usr/bin/sudo shutdown now

#tar -xzvf /opt/material.tar.gz --overwrite -C /
/usr/bin/sudo /usr/bin/systemctl restart systemd-poweroff.service