#!/bin/bash

if [ -f "/srv/http/config/yton" ]; then
    rm "/srv/http/config/yton"
fi

if [ ! -f "/srv/http/config/lmson" ]; then
    touch "/srv/http/config/lmson"
fi

tar -xzvf /srv/http/config/unit/lms.tar.gz --overwrite -C /
/usr/bin/sudo /usr/bin/systemctl daemon-reload
/usr/bin/sudo /usr/bin/systemctl restart localbrowser.service
/usr/bin/sudo /usr/bin/systemctl enable localbrowser.service

exit
