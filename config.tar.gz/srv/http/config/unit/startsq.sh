#!/bin/bash
/usr/bin/sudo /usr/bin/systemctl daemon-reload
/usr/bin/sudo /usr/bin/systemctl restart sq.service
/usr/bin/sudo chown http:http /etc/asound.conf