#!/bin/bash
/usr/bin/sudo /usr/bin/systemctl stop sq.service
#/usr/bin/sudo /usr/bin/systemctl stop logitechmediaserver-git.service
#/usr/bin/sudo reboot
/usr/bin/sudo /usr/bin/systemctl restart systemd-reboot.service