#!/bin/bash

if [ -f "/srv/http/config/lmson" ]; then
    rm "/srv/http/config/lmson"
fi

if [ ! -f "/srv/http/config/yton" ]; then
    touch "/srv/http/config/yton"
fi

tar -xzvf /srv/http/config/unit/ytube.tar.gz --overwrite -C /
/usr/bin/sudo /usr/bin/systemctl daemon-reload
/usr/bin/sudo /usr/bin/systemctl restart localbrowser.service
/usr/bin/sudo /usr/bin/systemctl enable localbrowser.service


exit
