#!/bin/bash

CONFIG_FILE="/srv/http/config/config.ini"
CONFIG_TXT="/boot/config.txt"


if [ "$1" == "I2S" ]; then
    TARGET_SECTION="[DAC]"
elif [ "$1" == "USB" ]; then
    TARGET_SECTION="[USB]"
else
    echo "Đối số không hợp lệ. Sử dụng 'I2S' hoặc 'USB'"
    exit 1
fi


if [ ! -f "$CONFIG_FILE" ]; then
    echo "File cấu hình $CONFIG_FILE không tồn tại."
    exit 1
fi




DTOVERLAY=$(grep "$TARGET_SECTION" -A 1 "$CONFIG_FILE" | awk -F "=" '/dtoverlay/{print $2}')


if [ -n "$DTOVERLAY" ]; then

    sed -i "/dtoverlay=/d" "$CONFIG_TXT"

    echo "dtoverlay=$DTOVERLAY" >> "$CONFIG_TXT"
    echo "Đã cập nhật dtoverlay trong $CONFIG_TXT"
else
    echo "Không tìm thấy dtoverlay trong mục $TARGET_SECTION của $CONFIG_FILE"
fi



if [ "$1" == "USB" ]; then
    sed -i "/dtoverlay=/d" "$CONFIG_TXT"
    echo "Đã xóa tất cả dtoverlay trong $CONFIG_TXT"
fi


if grep -q "dtoverlay=disable-bt" "$CONFIG_FILE"; then

    echo "dtoverlay=disable-bt" >> "$CONFIG_TXT"
    echo 'Added dtoverlay=disable-bt to config.txt.'
fi

