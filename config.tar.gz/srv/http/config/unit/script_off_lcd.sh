#!/bin/bash

/usr/bin/sudo /usr/bin/systemctl daemon-reload
/usr/bin/sudo /usr/bin/systemctl stop localbrowser.service
/usr/bin/sudo /usr/bin/systemctl disable localbrowser.service

if [ -f "/srv/http/config/lmson" ]; then
    rm "/srv/http/config/lmson"
fi

if [ -f "/srv/http/config/yton" ]; then
    rm "/srv/http/config/yton"
fi

# if [ -f "/srv/http/config/lcdon" ]; then
    # rm "/srv/http/config/lcdon"
# fi

exit
