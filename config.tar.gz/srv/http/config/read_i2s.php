<?php

$jsonFilePath = '/srv/http/assets/data/system-i2s.json';


$jsonData = file_get_contents($jsonFilePath);


$data = json_decode($jsonData, true);


// $logFilePath = '/srv/http/assets/data/log.txt';
// $logMessage = date('Y-m-d H:i:s') . ': JSON data accessed.' . PHP_EOL;
// file_put_contents($logFilePath, $logMessage, FILE_APPEND);


header('Content-Type: application/json');
echo json_encode($data);
?>
