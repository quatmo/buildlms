<?php

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["hdmiValue"])) {
    $selectedHdmiDrive = $_POST["hdmiValue"];

    if ($selectedHdmiDrive === "one") {
        $command = "/usr/bin/sudo /srv/http/config/unit/hdmipixel.sh one";
        $output = exec($command);
    } elseif ($selectedHdmiDrive === "two") {
        $command = "/usr/bin/sudo /srv/http/config/unit/hdmipixel.sh two";
        $output = exec($command);
    } else {
        echo 'Invalid HDMI.';
    }
} else {
    echo 'Invalid request.';
}

?>
