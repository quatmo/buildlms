<?php
$command = "/srv/http/eqfa12/unit/eq.sh && /srv/http/eqfa12/unit/startsq.sh";
$output = shell_exec($command);

// Kiểm tra xem lệnh đã thực thi thành công hay không
if ($output === null) {
    http_response_code(500); // Internal Server Error
    echo "Có lỗi xảy ra khi thực thi lệnh.";
} else {
    http_response_code(200); // OK
    echo "Lệnh đã thực thi thành công. Config thành công file /etc/alsa/conf.d/eqfa12p.conf";
}
?>
