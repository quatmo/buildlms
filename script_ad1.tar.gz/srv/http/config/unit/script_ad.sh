#!/bin/bash
systemctl stop localbrowser.service
if [ ! -f "/opt/ads" ]; then
	#sed -i 's/firefox -private -kiosk https:\/\/www.youtube.com\/tv/firefox -private https:\/\/www.youtube.com\/tv/g' /srv/http/bash/xinitrc
    sed -i 's/-kiosk//g' /srv/http/bash/xinitrc
	#touch /opt/ads
	#
else
    echo 'Ok'
	#tar -xzvf /srv/http/config/unit/ytube.tar.gz --overwrite -C /
fi


sleep 1
systemctl restart localbrowser.service
sleep 3


tar -xzvf /srv/http/config/unit/ytube.tar.gz --overwrite -C /


