<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $srvUsername = $_POST['srvUsername'];
    $srvPassword = $_POST['srvPassword'];
    $bubbleServerUrl = $_POST['bubbleServerUrl'];

    // Validate the input if needed

    // Update the config file content
    $configFilePath = '/srv/http/bub/config.inc.php';
    $configContent = "<?php\n\n";
    $configContent .= "\$_CONFIG['srv_username'] = \"$srvUsername\";\n";
    $configContent .= "\$_CONFIG['srv_password'] = \"$srvPassword\";\n";
    $configContent .= "\$_CONFIG['bubbleServerUrl'] = '$bubbleServerUrl';\n";
    $configContent .= "?>";

    file_put_contents($configFilePath, $configContent);

    // Provide a success message or any relevant response
    echo 'Config updated successfully! Access the LMSBubv9 Server menu. Choose the Server, option Folder view, select the music album you want to listen to, and press "Add Album" to play it in your LMS.';
} else {
    echo 'Invalid request method.';
}
?>
