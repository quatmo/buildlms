#!/bin/bash

/usr/bin/sudo /usr/bin/systemctl stop localbrowser.service
sleep 1
/usr/bin/sudo rm -rf /root/.cache/mozilla/firefox/*

sleep 1
/usr/bin/sudo /usr/bin/systemctl daemon-reload
sleep 1
/usr/bin/sudo /usr/bin/systemctl restart localbrowser.service

exit
