<?php
$command = "/usr/bin/sudo /srv/http/config/unit/script_reset_ytube.sh";
$output = shell_exec($command);

if ($outputre === null) {
    http_response_code(500);
    echo "Cannot reboot";
} else {
    http_response_code(200);
    echo "Reboot now";

}

?>
