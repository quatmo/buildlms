#!/bin/bash

if [ "$#" -ne 1 ] || ([ "$1" != "one" ] && [ "$1" != "two" ]); then
    echo "Invalid option. Use 'one' or 'two'."
    exit 1
fi
#hdmi_cvt_value="1280 720 60 3 0 0 0"
#hdmi_cvt_value="1920 1080 60 3 0 0 0"
if [ "$1" == "one" ]; then
    hdmi_mode_value=4
	if [ -e "/etc/X11/xorg.conf.d/10-monitor.conf" ]; then
		/usr/bin/sudo rm /etc/X11/xorg.conf.d/10-monitor.conf
	fi
elif [ "$1" == "two" ]; then
    hdmi_mode_value=5
	/usr/bin/sudo tar -xzvf /srv/http/config/unit/xorg1.tar.gz --overwrite -C /
fi

/usr/bin/sudo sed -i -E "s/(hdmi_mode=)[0-9]+/\1$hdmi_mode_value/" /boot/config.txt
/usr/bin/sudo sed -i -E "s/(hdmi_cvt=).*/\1$hdmi_cvt_value/" /boot/config.txt

echo "hdmi_mode set to $hdmi_mode_value."
echo "hdmi_cvt set to $hdmi_cvt_value."
